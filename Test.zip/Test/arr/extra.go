package main

import "fmt"

func sum(x  int,y int,z int) {

	total :=x+y+z
	fmt.Println(total)
}
func main() {



	sum(1, 2, 3)

}